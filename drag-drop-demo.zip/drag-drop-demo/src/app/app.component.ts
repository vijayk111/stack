import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { DragDropDirective } from './directives/drag-drop.directive';

@Component({
  selector: 'app-root',
  imports: [DragDropDirective],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  title = 'drag-drop-demo';
  files: File[] = [];

  onFileDropped(files: File[]) {
    this.files= files;
    console.log(files);
    this.uploadFiles();
  }

  uploadFiles() {
    // Implement file upload logic here
    for (const file of this.files) {
        // Handle the upload of each file
        console.log(file);
    }
  }
}
