package sample;

import java.util.Scanner;
import java.util.Stack;

public class PopMinMax {
	
		Stack<Integer> stack;
	    Stack<Integer> maxStack;
	    Stack<Integer> minStack;

	    public PopMinMax() {
	        stack = new Stack<Integer>();
	        maxStack = new Stack<Integer>();
	        minStack = new Stack<Integer>();
	    }

	    public void push(int x) {
	        int max = maxStack.isEmpty() ? x : maxStack.peek();
	        maxStack.push(max > x ? max : x);
	        
	        int min = minStack.isEmpty() ? x : minStack.peek();
	        minStack.push(min < x ? min : x);
	        
	        stack.push(x);
	    }

	    public void pop() {
	    	
	    	if(stack.peek() == minStack.peek())
	    	{
	    		System.out.println("top of the stack is min value, calling pop()");
	    		minStack.pop();
		        stack.pop();
		        System.out.println(stack);
	    	}
	    	else if(stack.peek() == maxStack.peek())
	    	{
	    		System.out.println("top of the stack is max value, calling pop()");
	    		maxStack.pop();
		        stack.pop();
		        System.out.println(stack);
	    	}
	    	else {
	    		System.out.println("top element is neither max nor min, if u want to continue poping other element type Yes or No to exit:");
	    		Scanner sc= new Scanner(System.in);
	    		String ch = sc.nextLine();
	    		switch(ch) {
	    		case "Yes" :
	    			stack.pop();
	    			System.out.println(stack);	 
	    			break;
	    		case "No" :
	    			System.out.println("exiting...");
	    			System.exit(0);
	    			break;
	    		default: 
	                System.out.println("no match");
	    		}
	    		sc.close();
	    	}
	    	
	    }

	    public int top() {
	        return stack.peek();
	    }

	    public int peekMax() {
	        return maxStack.peek();
	    }
	    
	    public int peekMin() {
	    	return minStack.peek();
	    }

	   /* public int popMax() {
	        int max = peekMax();
	        Stack<Integer> buffer = new Stack<Integer>();
	        while (top() != max) buffer.push(pop());
	        pop();
	        while (!buffer.isEmpty()) push(buffer.pop());
	        return max;
	    }
	    
	    public int popMin() {
	    	int min = peekMax();
	    	Stack<Integer> buffer = new Stack<Integer>();
	    	while(top() != min) buffer.push(pop());
	    	pop();
	    	while(!buffer.isEmpty()) push(buffer.pop());
	    	return min;
	    }
	    */
	public static void main(String[] args) {
		PopMinMax p= new PopMinMax();
		
		p.push(5);
		p.push(8);
		p.push(1);
		p.push(3);
		
		System.out.println(p.stack);
		System.out.println(p.maxStack);
		System.out.println(p.minStack);
		
		p.pop();
		System.out.println(p.stack);
		System.out.println(p.maxStack);
		System.out.println(p.minStack);
	}

}
