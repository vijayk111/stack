package com.example.config;

import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;

@Configuration
@EnableBatchProcessing
public class BatchConfig {

    @Bean
    public Job processJob(JobBuilderFactory jobBuilderFactory, Step step1) {
        return jobBuilderFactory.get("processJob")
                .incrementer(new RunIdIncrementer())
                .flow(step1)
                .end()
                .build();
    }

    @Bean
    public Step step1(StepBuilderFactory stepBuilderFactory, RecordProcessor processor, RecordWriter writer) {
        return stepBuilderFactory.get("step1")
                .<Record, Record>chunk(100)
                .processor(processor)
                .writer(writer)
                .build();
    }
}
