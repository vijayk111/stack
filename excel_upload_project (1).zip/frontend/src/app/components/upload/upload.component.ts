import { Component } from '@angular/core';
import { FileUploadService } from '../../services/file-upload.service';

@Component({
    selector: 'app-upload',
    templateUrl: './upload.component.html',
})
export class UploadComponent {
    constructor(private fileUploadService: FileUploadService) {}

    onFileSelected(event: any) {
        const file: File = event.target.files[0];
        if (file) {
            this.fileUploadService.uploadFile(file).subscribe(response => {
                alert(response);
            });
        }
    }
}
