package com.example.batch.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.batch.entity.Record;

public interface RecordRepository extends JpaRepository<Record, Long> {
}
