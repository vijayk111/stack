package com.example.batch;

import org.springframework.batch.item.ItemProcessor;
import com.example.entity.Record;

public class RecordProcessor implements ItemProcessor<Record, Record> {

    @Override
    public Record process(Record item) {
        item.setName(item.getName().toUpperCase());
        return item;
    }
}
