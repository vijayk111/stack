import { Component, OnInit } from '@angular/core';
import { SideNavComponent } from '../side-nav/side-nav.component';
import { CommonModule } from '@angular/common';
import { ThemeService } from '../../service/theme.service';
import { MatCardModule } from '@angular/material/card';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [SideNavComponent, CommonModule, MatCardModule],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss'
})
export class HomeComponent implements OnInit{

  isDarkTheme: boolean= false;

  cardData = [
    {
      title: 'Card 1',
      description: 'This is the description for Card 1.',
      imageUrl: 'https://via.placeholder.com/150',
    },
    {
      title: 'Card 2',
      description: 'This is the description for Card 1.',
      imageUrl: 'https://via.placeholder.com/150',
    },
    {
      title: 'Card 3',
      description: 'This is the description for Card 1.',
      imageUrl: 'https://via.placeholder.com/150',
    },
    {
      title: 'Card 4',
      description: 'This is the description for Card 1.',
      imageUrl: 'https://via.placeholder.com/150',
    },
    {
      title: 'Card 5',
      description: 'This is the description for Card 1.',
      imageUrl: 'https://via.placeholder.com/150',
    },
    {
      title: 'Card 6',
      description: 'This is the description for Card 1.',
      imageUrl: 'https://via.placeholder.com/150',
    },
    {
      title: 'Card 7',
      description: 'This is the description for Card 1.',
      imageUrl: 'https://via.placeholder.com/150',
    },
    {
      title: 'Card 8',
      description: 'This is the description for Card 1.',
      imageUrl: 'https://via.placeholder.com/150',
    },
  ];

  constructor(private themeService: ThemeService){
  }
  ngOnInit(): void {
    this.themeService.isDarkTheme$.subscribe((isDark) => {
      this.isDarkTheme = isDark;
    });
  }

}
