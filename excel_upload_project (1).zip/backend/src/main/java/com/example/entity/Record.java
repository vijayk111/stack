package com.example.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Record {

    @Id
    private Long id;
    private String name;
    private String email;

    // Getters and Setters
}
